package com.khh.book.book.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.khh.book.book.vo.BookVO;

@Repository("bookDAO")
public class BookDAOImpl implements BookDAO {

	@Autowired
	private SqlSession sqlSession;

	@Override
	public List selectAllBookList() throws DataAccessException {

		List<BookVO> booksList = null;
		booksList = sqlSession.selectList("mepper.book.selectAllBookList");
		
		return booksList;
	}

}
