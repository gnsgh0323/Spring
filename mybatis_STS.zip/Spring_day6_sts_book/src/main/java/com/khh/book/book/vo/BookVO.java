package com.khh.book.book.vo;

import org.springframework.stereotype.Component;

@Component("bookVO")
public class BookVO {
	
	private int sseq;
	private String title;
	private String content;
	
	public BookVO() {
	}

	public BookVO(int sseq, String title, String content) {
		this.sseq = sseq;
		this.title = title;
		this.content = content;
	}

	public int getSseq() {
		return sseq;
	}

	public void setSseq(int sseq) {
		this.sseq = sseq;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	
}
