package com.khh.book.book.service;

import java.util.List;

import org.springframework.dao.DataAccessException;

public interface BookService {

	public List listBooks() throws DataAccessException;

}
