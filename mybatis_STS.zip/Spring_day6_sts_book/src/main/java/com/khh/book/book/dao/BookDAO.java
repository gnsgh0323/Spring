package com.khh.book.book.dao;

import java.util.List;

import org.springframework.dao.DataAccessException;

public interface BookDAO {

	public List selectAllBookList() throws DataAccessException;

}
